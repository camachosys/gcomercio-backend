<?php
// Routes

$app->get('/', function ($request, $response, $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");
    // Render index view
    return $this->renderer->render($response, 'index.php', $args);
});


$app->get('/pregunta1', function ($request, $response, $args) {
    return $this->renderer->render($response, 'ChangeString.php', $args);
});

$app->get('/pregunta2', function ($request, $response, $args) {
    return $this->renderer->render($response, 'CompleteRange.php', $args);
});


$app->get('/pregunta3', function ($request, $response, $args) {
    return $this->renderer->render($response, 'ClearPar.php', $args);
});


$app->get('/pregunta4', function ($request, $response, $args) {
	$employees = json_decode(file_get_contents("employees.json"));	
    return $this->renderer->render($response, 'listado.php', $employees);
});

$app->get('/pregunta5', function ($request, $response, $args) {
    return $this->renderer->render($response, 'TestService.php', $args);
});



/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


$app->get('/busquedaxml', function($request, $response, $args) {

	
	$inicio  = ($request->getQueryParam("inicio"));
	$fin  = ($request->getQueryParam("fin"));
	
	$xml = new SimpleXMLElement("<?xml version='1.0' encoding='UTF-8'?><employees></employees>");
	$employees = json_decode(file_get_contents("employees.json"));
	
	foreach($employees as $emp){
	
		if(floatval(str_replace(",","",trim($emp->salary,"$")))>=floatval($inicio) && floatval(str_replace(",","",trim($emp->salary,"$")))<=floatval($fin))
		{
			$employee = $xml->addChild('employee');
			$employee->addChild('name',$emp->name);
			$employee->addChild('email',$emp->email);
			$employee->addChild('position',$emp->position);
			$employee->addChild('salary',$emp->salary);
		}
	}

	
	$response->getbody()->write($xml->asXml());
	return $response->withHeader(
        'Content-Type',
        'application/xml'
    );
});


$app->get('/detalle', function ($request, $response, $args) {
	$employees = json_decode(file_get_contents("employees.json"));	
	$id  = $request->getQueryParam("id");
	$search = array();
	foreach($employees as $emp){
		if(preg_match('/'.$id.'/' ,$emp->id ) )
		{
			array_push($search,$emp);
		}
	}
    return $this->renderer->render($response, 'detalle.php', $search );
});

$app->post('/pregunta4', function ($request, $response, $args) {
	$employees = json_decode(file_get_contents("employees.json"));	
	$email  = $request->getParam("txtemail");	
	$search = array();
	foreach($employees as $emp){
		if(preg_match('/'.$email.'/i' ,$emp->email ) )
		{
			array_push($search,$emp);
		}
	}
    return $this->renderer->render($response, 'listado.php', $search);
});
?>
