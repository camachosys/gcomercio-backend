<?php
function build($char){

	$chars = str_split($char);
	$chars2 = $chars;
	$charsout = $chars;
	$i = 0;
	$j = 0;
	foreach($chars as $x){
		unset($chars2[$i]);
		$j = $i;
		foreach($chars2 as $y){
			$j++;
			if($x=='(' && $y==')' && $charsout[$i]!='*' && $charsout[$j]!='*'){
				$charsout[$i] = '*';
				$charsout[$j] = '*';
			}
		}
		$i++;
	}
	$i = 0;
	$out = 'Entrada -> '.$char.'</br>';
	$out.= 'Salida -> ';
	foreach($chars as $x){
		if($charsout[$i]=='*'){
			$out.= $x;
		}
		$i++;
	}
	$out.= '</br>';
	return $out;
}
?>


<?
$test = ')()()(((())';

echo build($test);
?>
<a href=".">REGRESAR</a>