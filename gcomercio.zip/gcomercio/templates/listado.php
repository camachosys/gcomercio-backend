<!doctype html>
<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Listado de Empleados</title>
	</head>
    <body>
        <h2>Listado de Empleados</h2>
		<form action="" method="POST" role="form" style="margin:0 auto;max-width:600px;padding:15px;">
				<div>
					<label for="txtemail">Buscar</label>
					<input type="text"  id="txtemail" name="txtemail" placeholder="Introduzca Email">
					<button type="submit" >Buscar</button>
				</div>
		</form>
        <table border='1'>
		<th>NAME</th>
		<th>EMAIL</th>
		<th>POSITION</th>
		<th>SALARY</th>
		<th></th>
            <?php

				foreach($data as $emp) {
					echo '<tr><td>' . $emp->name . ' </td> <td>' . $emp->email. ' </td> <td>'. $emp->position.' </td> <td>' .$emp->salary. '</td>';
					echo '<td><a href="detalle?id='.$emp->id.'">< VER ></a></td></tr>';
				}
            ?>
        </table>
		<a href=".">REGRESAR</a>
    </body>
</html>