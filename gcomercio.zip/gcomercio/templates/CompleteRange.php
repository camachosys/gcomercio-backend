<?php
function build($in){

	$i = 0;
	$k = 0;
	$ino = array();
	foreach($in as $x){
	
		array_push($ino,$x);
		
		if($in[$i+1] - $x  > 1){
		 for($k = $x+1 ; $k<$in[$i+1] ; $k++){
			array_push($ino,$k);
		 }
		}

		$i++;
	}
	$i = 0;
	$out = 'Entrada -> [';
	
	foreach($in as $x){
		$out.= $x.',';
	}
	$out = rtrim($out,",");
	$out.= '] </br>';
	$out.= 'Salida -> [';
	foreach($ino as $x){
		$out.= $x.',';
	}
	$out = rtrim($out,",");
	$out.= '] </br>';
	return $out;
}
?>


<?
$test = array(55,58,60,70);

echo build($test);
?>
<a href=".">REGRESAR</a>