<!doctype html>
<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Test Servicio Web</title>
	</head>
    <body>
        <h2>Test Servicio Web</h2>
		<form action="busquedaxml" method="GET" role="form" style="margin:0 auto;max-width:600px;padding:15px;">
				<div>
					<label for="inicio">Inicio&nbsp;&nbsp;&nbsp;&nbsp;</label>
					<input type="text"  id="inicio" name="inicio" placeholder="Introduzca Salario Inicial"></BR>
					<label for="fin">Fin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
					<input type="text"  id="fin" name="fin" placeholder="Introduzca Salario Final"></BR>
					<button type="submit" >Test</button>
				</div>
		</form>
		<a href=".">REGRESAR</a>
    </body>
</html>