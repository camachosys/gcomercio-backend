<!doctype html>
<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Listado de Empleados</title>
	</head>
    <body>
        <h2>Listado de Empleados - Detalle</h2>

        <ul>
            <?php

				foreach($data as $emp) {
					echo '<li>NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    ->&nbsp; ' . $emp->name .'</li>';
					echo '<li>EMAIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   ->&nbsp; ' . $emp->email .'</li>';
					echo '<li>PHONE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   ->&nbsp; ' . $emp->phone .'</li>';
					echo '<li>ADDRESS&nbsp;&nbsp; ->&nbsp; ' . $emp->address .'</li>';
					echo '<li>POSITION&nbsp; ->&nbsp; ' . $emp->position .'</li>';
					echo '<li>SALARY&nbsp;&nbsp;&nbsp;&nbsp;  ->&nbsp; ' . $emp->salary .'</li>';
					echo '<li>SKILLS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  ->&nbsp; ' . json_encode($emp->skills).'</li>';
				}
            ?>
        </ul>
		<a href="pregunta4">REGRESAR</a>
    </body>
</html>