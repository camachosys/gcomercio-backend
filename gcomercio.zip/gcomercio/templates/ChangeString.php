<?php
function build($in){

	$out = 'Entrada -> '.$in.'</br>';
	$in= mb_convert_encoding($in, 'ISO-8859-1', 'UTF-8'); 
	$chars = str_split($in);
	$out.= 'Salida -> ';
	foreach($chars as $x){
		$code = ord($x);
		if($code == 209){
			$out.= chr(79);
		}elseif($code == 241){
			$out.= chr(111);
		}elseif($code >= 65 && $code <= 90){
			$out.= ($code==90)? chr(65):chr($code+1);
		}elseif($code >= 97 && $code <= 122){
			$out.= ($code==122)? chr(97):chr($code+1);
		}else{
			$out.= $x;
		}
	}
	$out.= '</br>';
	return $out;
}
?>


<?

$test = '**CaSañzZÑO**';

echo build($test);
?>
<a href=".">REGRESAR</a>