<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <title>Mario Camacho Medina</title>
        <style>
            body {
                margin: 50px 0 0 0;
                padding: 0;
                width: 100%;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                text-align: center;
                color: #aaa;
                font-size: 18px;
            }

            a {
                color: #719e40;
                letter-spacing: -3px;
                font-family: 'Lato', sans-serif;
                font-size: 30px;
                font-weight: 200;
                margin-bottom: 0;
            }
        </style>
    </head>
    <body>
	<a href="pregunta1">Pregunta 1</a></br>
	<a href="pregunta2">Pregunta 2</a></br>
	<a href="pregunta3">Pregunta 3</a></br>
	<a href="pregunta4">Pregunta 4</a></br>
	<a href="pregunta5">Pregunta 5</a></br>
    </body>
</html>
